<?php 

include 'config.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: index.php");
}

if (isset($_POST['submit'])) {
	
	$email = $_POST['email'];
	 
	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
		$num_rows = mysqli_num_rows($result);
		if ($num_rows) {

			$userdata = mysqli_fetch_array($query);
			$username = $userdata['username'];
			$token = $userdata['token'];

			 
 $to_email = "receipient@gmail.com";
			$subject = "Password Reset";
			$body = "Hi, $username Click here to change your password 
			http://localhost/login/forgot-password.php?token='$token' ";
			$sender_email = "From: asymon05@gmail.com ";

			if(mail($to_email,$email, $subject, $body, $sender_email)) {

				$_SESSION['msg'] = "Check your mail to reset your password ";
				header('location: index.php');
			} else {
				echo "Email Sending failed";
			}
		} else{
			echo "No Email Found";
		}
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Register Form - Pure Coding</title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Forgot Password</p>
			
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			
			<div class="input-group">
				<button name="submit" class="btn">Send Mail</button>
			</div>
		</form>
	</div>
</body>
</html>