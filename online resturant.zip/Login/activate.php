<?php 
	session_start();

	include 'config.php';

	if(isset($_GET['token'])){

		$token = $_GET['token'];

		$update_querry = " update users set status='active' where token='$token' ";

		$query = mysqli_query($conn, $update_querry);

		if($query){
			if(isset($_SESSION['msg'])){
				$_SESSION['msg'] = "&nbsp &nbsp &nbsp &nbsp &nbsp Account activated successfully";
				header('Location: index.php');
			}else{
				$_SESSION['msg'] = "you are logged out";
				header('Location: index.php');
			}
		}else{
			$_SESSION['msg'] = "Account not activated";
			header('Location: register.php');
		}


}
?>