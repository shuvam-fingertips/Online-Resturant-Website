 setInterval(showTime, 1000);

      function showTime(){
        let time = new Date();
        let hr = time.getHours();
        let min = time.getMinutes();
        let sec = time.getSeconds();
        AMPM = 'AM'; 

      if(hr > 12) {
        hr -= 12;
        AMPM = "PM";
      }
      if(hr == 0) {
        hr = 12;
        AMPM = "AM";
      }

      hr = hr < 10 ? "0" + hr : hr;
      min = min < 10 ? "0" + min : min;
      sec = sec < 10 ? "0" + sec : sec;

      let curentTime = hr + ":" + min + ":" + sec + AMPM; 

      document.getElementById('clock').innerHTML = curentTime;
  }
  showTime();

function val(){

          var n=document.getElementById("name").value;
  var p=document.getElementById("ph").value;
  var e=document.getElementById("email").value;
  var d=document.getElementById("date").value;
  var t=document.getElementById("tt").value;
  var no=document.getElementById("nop").value;
  if(n==null || n=="")
  {
    alert("Please Enter Your name!");
return false;
  }
  if(p.length!=10)
  {
    alert("Please Enter a Valid 10 Digit Phone number");
return false;
  }
  if(e==""){
    alert("Please Enter your valid email address!");
return false;
  }
  if(d==""){
    alert("Please select a booking date");
return false;
  }
   if(t==""){
    alert("Please select the time you want to take our services!");
return false;
  }
  if(no==="Select the number of person:"){
    alert("Please choose the number of person");
    return false;
  }

  var alert_items = document.querySelectorAll(".alert_item");
  var btns = document.querySelectorAll(".btn");
  var alert_wrapper = document.querySelector(".alert_wrapper");
  var close_btns = document.querySelectorAll(".close");

btns.forEach(function(btn, btn_index){
    btn.addEventListener("click", function(){
      alert_wrapper.classList.add("active");

      alert_items.forEach(function(alert_item, alert_index){
        if(confirm("Your Name: "+n+"\n"+"Your Phone Number: "+p+"\n"+"Date: "+d+"\n"+"Time: "+t+"\n")){
           if(btn_index != alert_index){
              alert_item.style.top = "50%";
            }}
        else{
          if(btn_index === alert_index){
              alert_item.style.top = "50%";
            }
        }
      })
    })
  })

  close_btns.forEach(function(close, close_index){
    close.addEventListener("click", function(){
      alert_wrapper.classList.remove("active");

      alert_items.forEach(function(alert_item, alert_index){
        alert_item.style.top = "-100%";
      })
    })
  })
return true;
}


 function fvalidate(){
  var fname=document.getElementById("fname").value;
  var eml=document.getElementById("eml").value;
  var msg=document.getElementById("massage").value;
  if(fname==""){
    alert("Please enter your first name");
    return false;
  }
  if(eml==""){
    alert("Please enter your valid email address");
    return false;
  }
  if(msg=="" || msg.length>100 || msg.length<4){
    alert("You have to write your feedback within 4-100 character");
    return false;
  }
if(confirm("Are you want to submit?")){
  alert("Thanks for your valuable feedback");
}
else{
  alert("Your feedback is too important for us!\nKindly try again to submit your feedback");

}
 }