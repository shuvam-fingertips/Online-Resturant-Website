<?php 

include 'confirm.php';


session_start();


if (isset($_POST['submit'])) {
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $email = $_POST['email'];
  $message = $_POST['message'];

  $insert_query = " INSERT INTO user_feedback (firstname, lastname, email, message) VALUES('$firstname', '$lastname', '$email', '$message') ";

  $res = mysqli_query($con, $insert_query);

  if($res){

    ?>
    <script>
      alert('data inserted successfully');

    </script>
    <?php
  } else {
    ?>
    <script>
      alert('data not inserted successfully');

    </script>
    <?php
  }

  
}


?>


<html>
<head>
  <title>THE RING</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">

  <link href="https://fonts.googleapis.com/css2?family=Oxygen&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital@1&family=Oxygen&display=swap" rel="stylesheet">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="myscr.js"></script>
  
</head>
<body>
<header>
<nav class="navbar navbar-default" id="header-nav">
  <div class="container">
     <div class="navbar-header">
      <a href="res.html" class="pull-left visible-md visible-lg">
      <div id="logo-img" alt="Logo image"></div>
     </a>
     <div class="navbar-brand">
      <a href="res.html"><h1>The Ring Restaurent</h1></a>
      <p id="pp">
        <img src="logo5.png" alt="ALWAYS AT YOUR SERVICE">
        <span>ALWAYS AT YOURS SERVICE</span>
      </p>
     </div>
     
   <div class="visible-xs"> 
      <div class="sr-only">Toggle navigation</div>
      <a href="menu-categories.html" class="glyphicon glyphicon-book">  Menu</a><br>
        <a href="abt.html" class="glyphicon glyphicon-info-sign">  About Us</a><br>
          <a href="table-reserve.html" class="glyphicon glyphicon-cutlery">  Table Reservation</a><br>
            <a href="home.html" class="glyphicon glyphicon-home">  Home</a>
     </div>
  </div>
  <div id="collapsable-nav" class="collapse navbar-collapse">
    <ul id="nav-list" class="nav navbar-nav navbar-right">
       <li>
        <a href="res.html">
          <span class="glyphicon glyphicon-home"></span><br class="hidden-xs"> Home
        </a>
      </li>
          <li>
        <a href="abt.html">
          <span class="glyphicon glyphicon-info-sign"></span><br class="hidden-xs">About
        </a>
      </li>
          <li>
        <a href="menu-categories.html">
          <span class="glyphicon glyphicon-book"></span><br class="hidden-xs">View Menu
        </a>
      </li>
      <li>
        <a href="table-reserve.html">
          <span class="glyphicon glyphicon-cutlery"></span><br class="hidden-xs">Table Reservation
        </a>
      </li>
    
       <br>
      

      <li id="phone" class="hidden-xs">
        <a href="tel:033 2546-2557">
          <span class="glyphicon glyphicon-earphone">  0332546-2557</span>
        </a><div>||We Deliver at where you want||</div>
      </li>
       <li id="eem" class="hidden-xs">
        <a href="email:ring@gmail.com">
          <span class="glyphicon glyphicon-envelope"> ring@gmail.com</span>
        </a>
      </li>
    </ul>
     <h4>
        <span id="clock" class="glow"></span>
      </h4>
  </div>
</div>
</nav>
<div id="call-btn" class="visible-xs">
  <a class="btn" href="tel: 033 2546-2557">
    <span class="glyphicon glyphicon-earphone"></span>
    033 2546-2557
  </a>
</div>
<div id="xs-deliver" class="text-center visible-xs">||We Deliver at Where you want||</div>
</header>
<body>
<section>

<link rel="stylesheet" type="text/css" href="css/style.css"></head>
  <div class="containerf">
    <form action="" method="POST" id="my-form">
   <div><marquee><strong><h2><font face="Comic Sans MS" color="red">Your Feedback Is Highly Appreciated</font></h2><strong></marquee></div>
      <div class="form-groupp">
        <label for="firstName"> First Name</label>
        <input type="name" id="fname" name="firstname">
      </div>

      <div class="form-groupp">
        <label for="latsName">Last Name</label>
        <input type="name" id="lastName" name="lastname">
      </div>

      <div class="form-groupp">
        <label for="email">Email</label>
        <input type="email" id="eml" name="email">
      </div>

      <div class="form-groupp">
        <label for="massage">Massage</label>
        <textarea name="message" id="massage" cols="30" rows="10"></textarea>
      </div>

      <button name="submit" class="fsub" onclick="return fvalidate()">Submit</button>
    </form>
  </div>
</section>
<footer class="panel-footer">
    <div class="container">
      <div class="row">
        <section id="hours" class="col-sm-4">
          <span>Hours:</span><br>
          Mon-Thurs: 11:30am - 9:30pm<br>
          Sat-Sun: 10:30am - 11:30pm<br>
          Friday Closed
          <hr class="visible-xs">
        </section>
        <section id="address" class="col-sm-4">
          <span>Address:</span><br>
         Sovabazar, Fariapukur, <br>Shyam Bazar, Kolkata, West Bengal 7000045
          <p>* Delivery with minimum order of 500/- plus 20/- charge for all deliveries.</p>
          <hr class="visible-xs">
        </section>
        <section id="testimonials" class="col-sm-4">
          <p>"The best all in one restaurant I've been to! And that's saying a lot, since I've been to many!"<br>-<b>Mr. Sushanta Bera</b>(Executive head of LINDA PVT. LTD.) </p>
          <p>"Amazing food! Great service! Couldn't ask for more! I'll be back again and again!"<br>-<b>Mrs. Sweta Roy</b>(CEO of Kazstroy India Services)</p>
        </section>
      </div>
      <div class="text-center" id="copy">&copy; Copyright The Ring Restaurent 2021</div>
    </div>
  </footer>
</body>
</html>