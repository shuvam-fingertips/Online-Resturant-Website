<?php 

session_start();


if (!isset($_SESSION['fullname'])) {
    header("Location: index.php");
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>THE RING</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Oxygen&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital@1&family=Oxygen&display=swap" rel="stylesheet">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="myscr.js"></script>
</head>
<body>
<header>
<nav class="navbar navbar-default" id="header-nav">
  <div class="container">
     <div class="navbar-header">
      <a href="res.html" class="pull-left visible-md visible-lg">
      <div id="logo-img" alt="Logo image"></div>
     </a>
     <div class="navbar-brand">
      <a href="res.html"><h1>The Ring Restaurent</h1></a>
      <p id="pp">
        <img src="logo5.png" alt="ALWAYS AT YOUR SERVICE">
        <span>ALWAYS AT YOURS SERVICE</span>
      </p>
     </div>
 <div class="visible-xs"> 
      <div class="sr-only">Toggle navigation</div>
      <a href="res.php" class="glyphicon glyphicon-home">  Home</a><br>
        <a href="abt.php" class="glyphicon glyphicon-info-sign">  About Us</a><br>
         <a href="table-reserve.php" class="glyphicon glyphicon-cutlery">  Table Reservation</a><br>
            <a href="feedback.php" class="glyphicon glyphicon-envelope">  Feedback</a>
     </div>
  </div>
  <div id="collapsable-nav" class="collapse navbar-collapse">
    <ul id="nav-list" class="nav navbar-nav navbar-right">
     

            <li>
      <li>
        <a href="res.php">
          <span class="glyphicon glyphicon-home"></span><br class="hidden-xs">Home
        </a>
      </li>
      <li>
        <a href="abt.php">
          <span class="glyphicon glyphicon-info-sign"></span><br class="hidden-xs">About
        </a>
      </li>
      <li>
        <a href="table-reserve.php">
          <span class="glyphicon glyphicon-cutlery"></span><br class="hidden-xs">Table Reservation
        </a>
      </li>
        <li>
        <a href="feedback.php">
          <span class="glyphicon glyphicon-comment"></span><br class="hidden-xs"> Feedback
        </a>
      </li><br>
      <li id="phone" class="hidden-xs">
        <a href="tel:033 2546-2557">
          <span class="glyphicon glyphicon-earphone">  0332546-2557</span>
        </a><div>||We Deliver at where you want||</div>
      </li>
      <li id="eem" class="hidden-xs">
        <a href="email:ring@gmail.com">
          <span class="glyphicon glyphicon-envelope"> ring@gmail.com</span>
        </a>
      </li>
      <li>
        <span class="glyphicon glyphicon-user"></span><?php echo "Welcome, " . $_SESSION['fullname']; ?>
    <a href="logout.php">Logout</a></li>
    </ul>
     <h4>
        <span id="clock" class="glow"></span>
      </h4>
  </div>
</div>
</nav>


<div id="call-btn" class="visible-xs">
	<a class="btn" href="tel: 033 2546-2557">
		<span class="glyphicon glyphicon-earphone"></span>
		033 2546-2557
	</a>
</div>
<div id="xs-deliver" class="text-center visible-xs">||We Deliver at Where you want||</div>
</header>
<div id="main-content" class="container">
  <h2 id="menu-categories-title" class="text-center copy"><font color="black">Our Delicious Dishes</font></h2>

  <section class="row">
      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L01</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/veg.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.140/-<span>(INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Bengali Veg Thali</h3>
            <p class="menu-item-details copy">This contain Dal,Baingan vaja,Bhendi sabjee,Aaloo posto,Roti(2pcs),Panner curry,Tomato chutney,papad,Misti Dhai,Rasgulla(2pcs) with white rice.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>

      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L02</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/fish.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.175/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Bengali Fish Thali</h3>
            <p class="menu-item-details copy">This contain Dal,Baingan vaja,Katla fried,Pui saag,Prwan malai curry(2pcs),Doi Bhetki,Tomato chutney,Papad,Rasgulla(2pcs) with white rice</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
      <!-- Add after every 2nd menu-item-tile -->
      <div class="clearfix visible-lg-block visible-md-block"></div>

      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L03</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/chicken.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.200/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Chicken Thali</h3>
            <p class="menu-item-details copy">This contain Dal,Baingan vaja,Aaloo vaja,Chicken salad,Mix Chicken sabji,Chicken kasa(4pcs),Pineapple chutney,Papad,Misti Dhai,Rasgulla(2pcs) with white rice.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>

      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L04</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/mutton.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.225/-<span>(INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Mutton Thali</h3>
            <p class="menu-item-details copy">This contain Dal,Baingan vaja,Aaloo vaja,Mutton salad,Mutton Rogan Josh,Mutton kasa(2pcs),Pineapple chutney,Papad,Misti dhai,Rasgulla(2pcs) with white rice.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
      <!-- Add after every 2nd menu-item-tile -->
      <div class="clearfix visible-lg-block visible-md-block"></div>

      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L05</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/egg.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.28/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Egg Currey and egg bhujiya</h3>
            <p class="menu-item-details copy">Delicious special Egg curry(2pcs) with tasty egg bhujia.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>

      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L06</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/polao.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.70/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Polao/Pilau</h3>
            <p class="menu-item-details copy">Pilaf, or pilau is a rice dish, with cashew nut,kismis.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
      <!-- Add after every 2nd menu-item-tile -->
      <div class="clearfix visible-lg-block visible-md-block"></div>
      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L07</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/kolhapuri.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.130/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Chicken Kolhapuri(4pcs)</h3>
            <p class="menu-item-details copy">Kolhapuri chicken made with fresh ground kolhapuri masala. This delicious, hot and spicy dish is popular in the restaurants.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L08</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/kadai.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.155/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy"> Pheswari Mutton Kadai(4pcs)</h3>
            <p class="menu-item-details copy">This peshwari mutton kadai is a Pakistani dish where the mutton is cooked as one pot dish with the aromatic and spicy masala and the combination of aroma coming from kasuri meethi coriander leaves and sauf is so tempting.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
      <div class="clearfix visible-lg-block visible-md-block"></div>
      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L09</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/mughlai.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.145/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Mughlai Chicken(4pcs)</h3>
            <p class="menu-item-details copy">Mughlai Chicken is a restaurant style, north Indian recipe with a creamy, dark brown onion gravy that will have you licking the plate! .</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
      <div class="menu-item-tile col-md-6">
        <div class="row">
          <div class="col-sm-5">
            <div class="menu-item-photo">
              <div>L10</div>
              <img class="img-responsive" width="250" height="150" src="img/menu/polao.jpg" alt="Item">
            </div>
            <div class="menu-item-price copy">Rs.70/-<span> (INR)</span></div>
          </div>
          <div class="menu-item-description col-sm-7">
            <h3 class="menu-item-title copy">Polao/Pilau</h3>
            <p class="menu-item-details copy">Pilaf, or pilau is a rice dish, with cashew nut,kismis.</p>
          </div>
        </div>
        <hr class="visible-xs">
      </div>
          
    </section>

</div>
<footer class="panel-footer">
    
    <div class="containerrrr">
      <div class="row">
        <section id="hours" class="col-sm-4">
          <span>Hours:</span><br>
          Mon-Thurs: 11:30am - 9:30pm<br>
          Sat-Sun: 10:30am - 11:30pm<br>
          Friday Closed
          <hr class="visible-xs">
        </section>
        <section id="address" class="col-sm-4">
          <span>Address:</span><br>
         Sovabazar, Fariapukur, <br>Shyam Bazar, Kolkata, West Bengal 7000045
          <p>* Delivery with minimum order of 500/- plus 20/- charge for all deliveries.</p>
          <hr class="visible-xs">
        </section>
        <section id="testimonials" class="col-sm-4">
          <p>"The best all in one restaurant I've been to! And that's saying a lot, since I've been to many!"<br>-<b>Mr. Sushanta Bera</b>(Executive head of LINDA PVT. LTD.) </p>
          <p>"Amazing food! Great service! Couldn't ask for more! I'll be back again and again!"<br>-<b>Mrs. Sweta Roy</b>(CEO of Kazstroy India Services)</p>
        </section>
      </div>
      <div class="text-center" id="copy">&copy; Copyright The Ring Restaurent 2021</div>
    </div>
  </footer>
</body>
</html>
